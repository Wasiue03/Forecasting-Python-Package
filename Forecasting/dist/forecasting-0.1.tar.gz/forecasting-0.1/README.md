# Forecasting Package

This package provides time series forecasting capabilities using ARIMA, SARIMA, and Exponential Smoothing models.

## Installation

You can install the package using pip:

```bash
pip install git+https://github.com/Wasiue03/Forecasting-Python-Package.git
