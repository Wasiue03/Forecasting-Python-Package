from setuptools import setup, find_packages

setup(
    name='forecasting',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'statsmodels',
        'optuna',
        'matplotlib',
        'numpy',
        'scikit-learn'
    ],
    entry_points={
        'console_scripts': [
            'forecasting=forecasting.forecast:main_forecasting',
        ],
    },
    python_requires='>=3.7',
    author='Abdul Wasiue',
    author_email='abdulwasiueunk@gmail.com',
    description='A package for time series forecasting using ARIMA, SARIMA, and Exponential Smoothing',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/Wasiue03/Forecasting-Python-Package',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
)
